Adding New Themes to Windows 3.1 or Windows For Workgroups 3.11.

1. Create a copy of your C:\WINDOWS\CONTROL.INI file so you can restore the original if anything goes wrong.

2. Open C:\WINDOWS\CONTROL.INI. If you double click it in File Manager, it should automatically open in Notepad.

3. Open SCHEMES.TXT from this package, and select all of the text in the file. Then copy the text block, and paste it beneath the [color schemes] heading in C:\WINDOWSCONTROL.INI.

4. Save CONTROL.INI. Your new themes should be available next time you go to Contol Panel > Colors.

5. The themes Corporate, Eminence and Summer of Love, have their own desktop wallpaper, which is included in this package. The bitmaps are...

Corporat.bmp
Eminence.bmp
Love.bmp

Copy all of the bitmaps to your C:\WINDOWS folder. You will then be able to load them via Control Panel > Desktop. Make sure you set the image to Tile, so that it fills screens larger than the standard 640 x 480 resolution.

Package provided by socket5.blogspot.com.